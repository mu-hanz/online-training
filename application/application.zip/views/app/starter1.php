<!-- Start Content-->
<div class="container-fluid">
    <div class="row page-title">
        <div class="col-md-12">
            <nav aria-label="breadcrumb" class="float-right mt-1">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="#">Shreyu</a></li>
                    <li class="breadcrumb-item"><a href="#">Pages</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Starter</li>
                </ol>
            </nav>
            <?php echo $content_use_tpl;?><br>
            <?php echo $content_not_tpl;?>
        
        </div>
    </div>
</div> <!-- container-fluid -->